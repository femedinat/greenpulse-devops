# Evidencias - GreenPulse

Este arquivo serve como modelo para registrar as evidencias de funcionamento do projeto GreenPulse no contexto da atividade academica.

## 1. Execucao local com Docker

### Evidencia

- Link ou caminho do print:
- Data da execucao:
- Comando utilizado:

```bash
docker compose up --build
```

### Observacoes

Descreva aqui se os containers `greenpulse-app` e `greenpulse-db` subiram corretamente.

## 2. Aplicacao local

### Evidencia

- Link ou caminho do print da aplicacao:
- URL acessada: `http://localhost:8080`
- URL do health check: `http://localhost:8080/actuator/health`

### Observacoes

Descreva aqui o retorno obtido na aplicacao e no health check.

## 3. Banco de dados PostgreSQL

### Evidencia

- Link ou caminho do print:
- Comando usado para verificar:

```bash
docker exec -it greenpulse-db psql -U greenpulse -d greenpulse
```

### Observacoes

Descreva aqui se o banco foi criado e se o container ficou saudavel.

## 4. Pipeline CI

### Evidencia

- Link ou caminho do print do GitHub Actions:
- Branch executada:
- Commit:

### Observacoes

Descreva aqui se as etapas de checkout, setup do Java, cache Maven, build e testes foram concluidas com sucesso.

## 5. Deploy em staging

### Evidencia

- Link ou caminho do print:
- Branch: `develop`
- Job: `deploy-staging`

### Observacoes

Descreva aqui a simulacao do deploy para staging e a tag Docker gerada.

## 6. Deploy em production

### Evidencia

- Link ou caminho do print:
- Branch: `main`
- Job: `deploy-production`

### Observacoes

Descreva aqui a simulacao do deploy para production e, se aplicavel, a aprovacao manual configurada no GitHub Environment.

## 7. Desafios encontrados

Liste os principais problemas encontrados durante a execucao.

- Exemplo: porta 5432 ja estava em uso localmente.
- Exemplo: Docker Desktop nao estava iniciado.
- Exemplo: variavel de ambiente incorreta no arquivo `.env`.

## 8. Solucoes aplicadas

Liste como cada problema foi resolvido.

- Exemplo: alterar `DB_PORT` no `.env`.
- Exemplo: reiniciar Docker Desktop.
- Exemplo: recriar containers com `docker compose down -v` e `docker compose up --build`.
