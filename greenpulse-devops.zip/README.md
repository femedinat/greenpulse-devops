# Projeto - GreenPulse

## Descricao do projeto

O **GreenPulse** e uma aplicacao Java Spring Boot com tema ESG, criada para simular uma plataforma web de monitoramento inteligente de consumo de energia. A proposta considera um dashboard com indicadores energeticos, alertas de consumo e conceito de integracao com sensores IoT.

Este repositorio tambem inclui uma estrutura DevOps simples e profissional para um cenario de producao simulado, usando CI/CD, Docker, Docker Compose, PostgreSQL e ambientes separados de staging e production.

## Como executar localmente com Docker

### 1. Clonar o repositorio

```bash
git clone <url-do-repositorio>
cd greenpulse
```

### 2. Criar o arquivo de variaveis de ambiente

```bash
cp .env.example .env
```

Edite o arquivo `.env` se quiser alterar porta da aplicacao, nome do banco ou credenciais.

### 3. Subir aplicacao e banco com Docker Compose

```bash
docker compose up --build
```

O Docker Compose ira:

- construir a imagem da aplicacao Spring Boot;
- iniciar um container PostgreSQL;
- criar uma rede dedicada;
- criar um volume persistente para os dados do banco;
- iniciar a aplicacao apos o banco estar saudavel.

### 4. Acessar a aplicacao

Com a configuracao padrao:

- Aplicacao: `http://localhost:8080`
- Endpoint simulado de energia: `http://localhost:8080/api/energy/status`
- Health check do Spring Actuator: `http://localhost:8080/actuator/health`

### 5. Verificar o banco de dados

Para acessar o PostgreSQL dentro do container:

```bash
docker exec -it greenpulse-db psql -U greenpulse -d greenpulse
```

Para listar os containers em execucao:

```bash
docker compose ps
```

Para parar o ambiente:

```bash
docker compose down
```

Para remover tambem o volume do banco:

```bash
docker compose down -v
```

## Pipeline CI/CD

A ferramenta utilizada para CI/CD e o **GitHub Actions**, com o workflow definido em `.github/workflows/ci-cd.yml`.

### Etapa de CI

A etapa de integracao continua executa em pushes e pull requests para as branches `develop` e `main`.

Ela realiza:

- checkout do codigo;
- configuracao do Java 17;
- cache das dependencias Maven;
- build do projeto;
- execucao dos testes automatizados com `mvn clean verify`.

### Deploy para staging

O job `deploy-staging` roda somente quando ha push na branch `develop`.

Ele simula:

- build da imagem Docker;
- criacao de tag com o hash do commit;
- deploy para ambiente de staging;
- uso do profile Spring `staging`.

### Deploy para production

O job `deploy-production` roda somente quando ha push na branch `main`.

Ele simula:

- build da imagem Docker;
- criacao de tag de producao com o hash do commit;
- deploy para ambiente de production;
- uso do profile Spring `prod`.

O workflow usa `environment: production`, permitindo configurar aprovacao manual no GitHub antes do deploy real.

## Containerizacao

### Dockerfile

O `Dockerfile` usa multi-stage build:

- a primeira etapa usa Maven com JDK 17 para baixar dependencias e gerar o `.jar`;
- a segunda etapa usa uma imagem leve com JRE 17 para executar a aplicacao;
- a aplicacao roda com usuario sem privilegios;
- a porta `8080` fica exposta por padrao.

### Docker Compose

O `docker-compose.yml` define dois servicos principais:

- `app`: aplicacao Spring Boot GreenPulse;
- `db`: banco PostgreSQL.

Tambem sao configurados:

- rede dedicada `greenpulse-network`;
- volume persistente `greenpulse-db-data`;
- variaveis de ambiente para conexao com banco;
- healthcheck no PostgreSQL;
- dependencia da aplicacao em relacao ao banco.

## Estrutura do projeto

```text
greenpulse/
├── Dockerfile
├── docker-compose.yml
├── .dockerignore
├── .gitignore
├── .env.example
├── README.md
├── pom.xml
├── src/
│   ├── main/
│   │   ├── java/com/greenpulse/
│   │   │   ├── GreenPulseApplication.java
│   │   │   └── HealthController.java
│   │   └── resources/
│   │       ├── application.properties
│   │       ├── application-staging.properties
│   │       └── application-prod.properties
│   └── test/java/com/greenpulse/
│       └── GreenPulseApplicationTests.java
├── .github/
│   └── workflows/
│       └── ci-cd.yml
└── docs/
    └── evidencias.md
```

## Prints do funcionamento

Insira abaixo as evidencias visuais solicitadas no trabalho:

- [ ] Print do pipeline rodando no GitHub Actions
- [ ] Print do job de staging executado
- [ ] Print do job de production executado
- [ ] Print da aplicacao acessada localmente
- [ ] Print do endpoint `/actuator/health`
- [ ] Print do Docker Desktop ou terminal mostrando containers rodando
- [ ] Print do PostgreSQL em execucao

## Tecnologias utilizadas

- Java 17
- Spring Boot
- Maven
- PostgreSQL
- Docker
- Docker Compose
- GitHub Actions
- Spring Data JPA
- Spring Boot Actuator

## Checklist de entrega

- [x] Aplicacao Java Spring Boot configurada
- [x] Build com Maven
- [x] Dockerfile funcional com multi-stage build
- [x] Docker Compose com aplicacao e PostgreSQL
- [x] Variaveis de ambiente documentadas em `.env.example`
- [x] Configuracao Spring Boot usando variaveis de ambiente
- [x] Profiles separados para staging e prod
- [x] Pipeline CI com build e testes
- [x] Pipeline CD com deploy simulado para staging
- [x] Pipeline CD com deploy simulado para production
- [x] README tecnico em portugues
- [x] Arquivo de evidencias para preenchimento
- [ ] Prints adicionados no README ou em `docs/evidencias.md`
- [ ] Repositorio enviado ou compactado em `.zip`

## Observacoes para adaptacao no projeto real

Caso este material seja aplicado sobre um projeto Spring Boot ja existente, mantenha sua estrutura de pacotes, controllers, services e entidades. Nesse caso, copie apenas os arquivos DevOps e ajuste o `pom.xml` somente se faltarem dependencias como PostgreSQL, JPA, Actuator ou testes.
